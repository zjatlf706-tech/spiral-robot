#ifndef INC_AK40_H_
#define INC_AK40_H_

#include "main.h"
#include <stdint.h>

/*
 * CubeMars AK40-10 UART 통신 속도
 */
#define AK40_BAUDRATE 921600


/*
 * CubeMars / VESC Communication Packet ID
 */
typedef enum
{
    COMM_FW_VERSION = 0,
    COMM_JUMP_TO_BOOTLOADER,
    COMM_ERASE_NEW_APP,
    COMM_WRITE_NEW_APP_DATA,

    COMM_GET_VALUES,             // 4

    COMM_SET_DUTY,               // 5
    COMM_SET_CURRENT,            // 6
    COMM_SET_CURRENT_BRAKE,      // 7
    COMM_SET_RPM,                // 8
    COMM_SET_POS,                // 9

    COMM_SET_HANDBRAKE,          // 10
    COMM_SET_DETECT,             // 11

    COMM_ROTOR_POSITION = 22,

    COMM_GET_VALUES_SETUP = 50,

    COMM_SET_POS_SPD = 91,
    COMM_SET_POS_MULTI = 92,
    COMM_SET_POS_SINGLE = 93,
    COMM_SET_POS_UNLIMITED = 94,
    COMM_SET_POS_ORIGIN = 95

} COMM_PACKET_ID;


/*
 * AK40에서 사용할 UART 지정
 *
 * 예:
 * AK40_Init(&huart6);
 */
void AK40_Init(UART_HandleTypeDef *huart);


/*
 * CRC16 계산
 */
uint16_t AK40_CRC16(const uint8_t *data, uint16_t length);


/*
 * 위치 제어
 *
 * 예:
 * AK40_SetPosition(90.0f);
 */
HAL_StatusTypeDef AK40_SetPosition(float degrees);


/*
 * 위치 + 속도 + 가속도 제어
 *
 * 예:
 * AK40_SetPositionSpeed(180.0f, 500.0f, 1000.0f);
 */
HAL_StatusTypeDef AK40_SetPositionSpeed(float degrees,
                                       float rpm_limit,
                                       float acceleration);

#endif /* INC_AK40_H_ */