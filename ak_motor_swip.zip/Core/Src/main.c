/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */


/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "usart.h"
#include "gpio.h"


/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "ak40.h"
#include <string.h>

/* USER CODE END Includes */


/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */


/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */


/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */


/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */


/* Private function prototypes -----------------------------------------------*/

void SystemClock_Config(void);

/* USER CODE BEGIN PFP */

void Debug_Print(const char *message);

/* USER CODE END PFP */


/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */


/**
  * @brief  PC Serial Monitor 문자열 출력
  *
  * USART2
  * PA2  = TX
  * PA3  = RX
  *
  * Baudrate = 115200
  */
void Debug_Print(const char *message)
{
    HAL_UART_Transmit(
        &huart2,
        (uint8_t *)message,
        strlen(message),
        HAL_MAX_DELAY
    );
}


/* USER CODE END 0 */


/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */


  /* MCU Configuration--------------------------------------------------------*/


  /*
   * Reset of all peripherals,
   * Initializes the Flash interface and the Systick.
   */
  HAL_Init();


  /* USER CODE BEGIN Init */

  /* USER CODE END Init */


  /*
   * Configure the system clock
   */
  SystemClock_Config();


  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */


  /*
   * Initialize all configured peripherals
   */
  MX_GPIO_Init();

  MX_DMA_Init();

  /*
   * PC Debug UART
   *
   * USART2
   * PA2  TX
   * PA3  RX
   * 115200 bps
   */
  MX_USART2_UART_Init();

  /*
   * CubeMars AK40-10 UART
   *
   * USART6
   * PA11 TX
   * PA12 RX
   * 921600 bps
   */
  MX_USART6_UART_Init();


  /* USER CODE BEGIN 2 */


  /*
   * ============================================================
   * AK40-10 UART 등록
   * ============================================================
   *
   * ak40.c에서 사용할 UART를 USART6으로 지정합니다.
   */
  AK40_Init(&huart6);


  /*
   * ============================================================
   * 시작 메시지
   * ============================================================
   */
  Debug_Print(
      "\r\n"
      "========================================\r\n"
      " STM32F401RE + CubeMars AK40-10\r\n"
      "========================================\r\n"
      "Motor UART : USART6\r\n"
      "Motor Baud : 921600 bps\r\n"
      "Debug UART : USART2\r\n"
      "Debug Baud : 115200 bps\r\n"
      "========================================\r\n"
      "\r\n"
  );


  /*
   * 부팅 후 약간 대기
   */
  HAL_Delay(1000);


  Debug_Print(
      "[SYSTEM] AK40 motor control start\r\n"
  );


  /* USER CODE END 2 */


  /* Infinite loop */

  /* USER CODE BEGIN WHILE */

  while (1)
  {

    /*
     * ==========================================================
     * 1. 90도 이동
     * ==========================================================
     */
    Debug_Print(
        "\r\n"
        "[MOTOR] Moving to 90 degrees...\r\n"
    );


    if (AK40_SetPosition(90.0f) == HAL_OK)
    {
        Debug_Print(
            "[TX] Position 90 : OK\r\n"
        );
    }
    else
    {
        Debug_Print(
            "[TX] Position 90 : ERROR\r\n"
        );
    }


    HAL_Delay(2000);



    /*
     * ==========================================================
     * 2. 180도 이동
     * ==========================================================
     */
    Debug_Print(
        "\r\n"
        "[MOTOR] Moving to 180 degrees...\r\n"
    );


    if (AK40_SetPosition(180.0f) == HAL_OK)
    {
        Debug_Print(
            "[TX] Position 180 : OK\r\n"
        );
    }
    else
    {
        Debug_Print(
            "[TX] Position 180 : ERROR\r\n"
        );
    }


    HAL_Delay(2000);



    /*
     * ==========================================================
     * 3. 270도 이동
     * ==========================================================
     */
    Debug_Print(
        "\r\n"
        "[MOTOR] Moving to 270 degrees...\r\n"
    );


    if (AK40_SetPosition(270.0f) == HAL_OK)
    {
        Debug_Print(
            "[TX] Position 270 : OK\r\n"
        );
    }
    else
    {
        Debug_Print(
            "[TX] Position 270 : ERROR\r\n"
        );
    }


    HAL_Delay(2000);



    /*
     * ==========================================================
     * 4. 360도 이동
     * ==========================================================
     */
    Debug_Print(
        "\r\n"
        "[MOTOR] Moving to 360 degrees...\r\n"
    );


    if (AK40_SetPosition(360.0f) == HAL_OK)
    {
        Debug_Print(
            "[TX] Position 360 : OK\r\n"
        );
    }
    else
    {
        Debug_Print(
            "[TX] Position 360 : ERROR\r\n"
        );
    }


    HAL_Delay(2000);



    /*
     * ==========================================================
     * 5. 위치 + 속도 + 가속도 제어
     *
     * 목표 위치 : 180도
     * 속도 제한 : 500
     * 가속도    : 1000
     * ==========================================================
     */
    Debug_Print(
        "\r\n"
        "[MOTOR] Moving to 180 degrees slowly...\r\n"
    );


    if (AK40_SetPositionSpeed(
            180.0f,
            500.0f,
            1000.0f
        ) == HAL_OK)
    {
        Debug_Print(
            "[TX] Position-Speed 180 : OK\r\n"
        );
    }
    else
    {
        Debug_Print(
            "[TX] Position-Speed 180 : ERROR\r\n"
        );
    }


    HAL_Delay(4000);



    /*
     * ==========================================================
     * 6. 0도 복귀
     *
     * 목표 위치 : 0도
     * 속도 제한 : 2000
     * 가속도    : 3000
     * ==========================================================
     */
    Debug_Print(
        "\r\n"
        "[MOTOR] Moving to 0 degrees quickly...\r\n"
    );


    if (AK40_SetPositionSpeed(
            0.0f,
            2000.0f,
            3000.0f
        ) == HAL_OK)
    {
        Debug_Print(
            "[TX] Position-Speed 0 : OK\r\n"
        );
    }
    else
    {
        Debug_Print(
            "[TX] Position-Speed 0 : ERROR\r\n"
        );
    }


    HAL_Delay(4000);


    Debug_Print(
        "\r\n"
        "----------------------------------------\r\n"
        "[SYSTEM] Motor sequence completed\r\n"
        "[SYSTEM] Restarting sequence...\r\n"
        "----------------------------------------\r\n"
    );


    HAL_Delay(1000);


    /* USER CODE END WHILE */


    /* USER CODE BEGIN 3 */

  }

  /* USER CODE END 3 */
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct = {0};

  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};


  /**
    * Configure the main internal regulator output voltage
    */
  __HAL_RCC_PWR_CLK_ENABLE();

  __HAL_PWR_VOLTAGESCALING_CONFIG(
      PWR_REGULATOR_VOLTAGE_SCALE2
  );


  /**
    * Initializes the RCC Oscillators
    */
  RCC_OscInitStruct.OscillatorType =
      RCC_OSCILLATORTYPE_HSI;

  RCC_OscInitStruct.HSIState =
      RCC_HSI_ON;

  RCC_OscInitStruct.HSICalibrationValue =
      RCC_HSICALIBRATION_DEFAULT;

  RCC_OscInitStruct.PLL.PLLState =
      RCC_PLL_NONE;


  if (HAL_RCC_OscConfig(
          &RCC_OscInitStruct
      ) != HAL_OK)
  {
    Error_Handler();
  }


  /**
    * Initializes CPU, AHB and APB buses clocks
    */
  RCC_ClkInitStruct.ClockType =
      RCC_CLOCKTYPE_HCLK |
      RCC_CLOCKTYPE_SYSCLK |
      RCC_CLOCKTYPE_PCLK1 |
      RCC_CLOCKTYPE_PCLK2;


  RCC_ClkInitStruct.SYSCLKSource =
      RCC_SYSCLKSOURCE_HSI;


  RCC_ClkInitStruct.AHBCLKDivider =
      RCC_SYSCLK_DIV1;


  RCC_ClkInitStruct.APB1CLKDivider =
      RCC_HCLK_DIV1;


  RCC_ClkInitStruct.APB2CLKDivider =
      RCC_HCLK_DIV1;


  if (HAL_RCC_ClockConfig(
          &RCC_ClkInitStruct,
          FLASH_LATENCY_0
      ) != HAL_OK)
  {
    Error_Handler();
  }
}


/* USER CODE BEGIN 4 */

/* USER CODE END 4 */


/**
  * @brief  This function is executed
  *         in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{

  /* USER CODE BEGIN Error_Handler_Debug */

  __disable_irq();


  while (1)
  {
  }

  /* USER CODE END Error_Handler_Debug */
}


#ifdef USE_FULL_ASSERT


/**
  * @brief Reports the name of the source file
  *        and the source line number where
  *        the assert_param error has occurred.
  *
  * @param file pointer to source file name
  * @param line assert_param error line
  *
  * @retval None
  */
void assert_failed(
    uint8_t *file,
    uint32_t line
)
{

  /* USER CODE BEGIN 6 */

  /*
   * User can add implementation here.
   *
   * Example:
   *
   * printf(
   *     "Wrong parameters value: file %s on line %d\r\n",
   *     file,
   *     line
   * );
   */

  /* USER CODE END 6 */
}


#endif /* USE_FULL_ASSERT */