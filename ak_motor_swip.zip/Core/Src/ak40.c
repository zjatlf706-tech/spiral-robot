#include "ak40.h"


/*
 * AK40-10 통신에 사용할 UART 핸들
 *
 * main.c에서
 *
 * AK40_Init(&huart6);
 *
 * 를 실행하면 &huart6가 저장됩니다.
 */
static UART_HandleTypeDef *ak40_uart = NULL;


/*
 * ============================================================
 * AK40_Init
 * ============================================================
 *
 * 사용할 UART를 AK40 드라이버에 등록합니다.
 *
 * CubeMX:
 *
 * USART6
 * TX = PA11
 * RX = PA12
 * Baud = 921600
 *
 */
void AK40_Init(UART_HandleTypeDef *huart)
{
    ak40_uart = huart;
}


/*
 * ============================================================
 * CRC16
 * ============================================================
 *
 * 기존 Arduino 코드의 CRC16과 같은
 * CRC-16/CCITT polynomial 0x1021
 *
 * 초기값 = 0x0000
 */
uint16_t AK40_CRC16(const uint8_t *data, uint16_t length)
{
    uint16_t crc = 0;

    for (uint16_t i = 0; i < length; i++)
    {
        crc ^= ((uint16_t)data[i] << 8);

        for (uint8_t bit = 0; bit < 8; bit++)
        {
            if (crc & 0x8000)
            {
                crc = (uint16_t)((crc << 1) ^ 0x1021);
            }
            else
            {
                crc <<= 1;
            }
        }
    }

    return crc;
}


/*
 * ============================================================
 * AK40_SetPosition
 * ============================================================
 *
 * 위치 제어 명령
 *
 * Packet:
 *
 * 02
 * 05
 * 09
 * Position[4]
 * CRC_H
 * CRC_L
 * 03
 *
 *
 * Payload:
 *
 * [0]     COMM_SET_POS = 9
 * [1~4]   Position
 *
 *
 * Position:
 *
 * degree × 1,000,000
 *
 * Big-Endian
 *
 */
HAL_StatusTypeDef AK40_SetPosition(float degrees)
{
    if (ak40_uart == NULL)
    {
        return HAL_ERROR;
    }


    /*
     * ------------------------------
     * Payload
     * ------------------------------
     */
    uint8_t payload[5];

    payload[0] = COMM_SET_POS;


    /*
     * 기존 Arduino 코드와 동일
     *
     * 90도
     * →
     * 90 × 1,000,000
     */
    int32_t position =
        (int32_t)(degrees * 1000000.0f);


    /*
     * Big-Endian
     */
    payload[1] = (uint8_t)((position >> 24) & 0xFF);
    payload[2] = (uint8_t)((position >> 16) & 0xFF);
    payload[3] = (uint8_t)((position >> 8) & 0xFF);
    payload[4] = (uint8_t)(position & 0xFF);


    /*
     * ------------------------------
     * Packet 생성
     * ------------------------------
     */
    uint8_t packet[10];

    uint16_t index = 0;


    /*
     * Start byte
     */
    packet[index++] = 0x02;


    /*
     * Payload length
     */
    packet[index++] = sizeof(payload);


    /*
     * Payload 복사
     */
    for (uint8_t i = 0; i < sizeof(payload); i++)
    {
        packet[index++] = payload[i];
    }


    /*
     * CRC 계산
     */
    uint16_t crc =
        AK40_CRC16(payload, sizeof(payload));


    /*
     * CRC Big-Endian
     */
    packet[index++] = (uint8_t)((crc >> 8) & 0xFF);
    packet[index++] = (uint8_t)(crc & 0xFF);


    /*
     * Stop byte
     */
    packet[index++] = 0x03;


    /*
     * STM32 → AK40-10
     */
    return HAL_UART_Transmit(
        ak40_uart,
        packet,
        index,
        HAL_MAX_DELAY
    );
}


/*
 * ============================================================
 * AK40_SetPositionSpeed
 * ============================================================
 *
 * 위치 + 속도 + 가속도 제어
 *
 * COMM_SET_POS_SPD = 91
 *
 *
 * Payload
 *
 * [0]      Command
 * [1~4]    Position
 * [5~8]    Speed
 * [9~12]   Acceleration
 *
 */
HAL_StatusTypeDef AK40_SetPositionSpeed(float degrees,
                                       float rpm_limit,
                                       float acceleration)
{
    if (ak40_uart == NULL)
    {
        return HAL_ERROR;
    }


    /*
     * Payload = 13 bytes
     */
    uint8_t payload[13];


    /*
     * Command ID
     */
    payload[0] = COMM_SET_POS_SPD;


    /*
     * 기존 Arduino 코드와 동일한 scale
     */
    int32_t position =
        (int32_t)(degrees * 1000000.0f);

    int32_t speed =
        (int32_t)(rpm_limit * 1000.0f);

    int32_t accel =
        (int32_t)(acceleration * 1000.0f);


    /*
     * ------------------------------
     * Position
     * ------------------------------
     */
    payload[1] = (uint8_t)((position >> 24) & 0xFF);
    payload[2] = (uint8_t)((position >> 16) & 0xFF);
    payload[3] = (uint8_t)((position >> 8) & 0xFF);
    payload[4] = (uint8_t)(position & 0xFF);


    /*
     * ------------------------------
     * Speed
     * ------------------------------
     */
    payload[5] = (uint8_t)((speed >> 24) & 0xFF);
    payload[6] = (uint8_t)((speed >> 16) & 0xFF);
    payload[7] = (uint8_t)((speed >> 8) & 0xFF);
    payload[8] = (uint8_t)(speed & 0xFF);


    /*
     * ------------------------------
     * Acceleration
     * ------------------------------
     */
    payload[9]  = (uint8_t)((accel >> 24) & 0xFF);
    payload[10] = (uint8_t)((accel >> 16) & 0xFF);
    payload[11] = (uint8_t)((accel >> 8) & 0xFF);
    payload[12] = (uint8_t)(accel & 0xFF);


    /*
     * Packet:
     *
     * 02
     * 0D
     * payload[13]
     * CRC_H
     * CRC_L
     * 03
     */
    uint8_t packet[18];

    uint16_t index = 0;


    /*
     * Start byte
     */
    packet[index++] = 0x02;


    /*
     * Payload length = 13
     */
    packet[index++] = sizeof(payload);


    /*
     * Payload
     */
    for (uint8_t i = 0; i < sizeof(payload); i++)
    {
        packet[index++] = payload[i];
    }


    /*
     * CRC
     */
    uint16_t crc =
        AK40_CRC16(payload, sizeof(payload));


    packet[index++] =
        (uint8_t)((crc >> 8) & 0xFF);

    packet[index++] =
        (uint8_t)(crc & 0xFF);


    /*
     * Stop byte
     */
    packet[index++] = 0x03;


    /*
     * 실제 UART 전송
     */
    return HAL_UART_Transmit(
        ak40_uart,
        packet,
        index,
        HAL_MAX_DELAY
    );
}